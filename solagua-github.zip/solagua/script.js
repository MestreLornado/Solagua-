'use strict';

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const constants = { h: 6.62607015e-34, c: 299792458, k: 1.380649e-23, sigma: 5.670374419e-8, b: 2.897771955e-3, eV: 1.602176634e-19 };

function format(value, digits=2) {
  return new Intl.NumberFormat('pt-BR', {maximumFractionDigits:digits}).format(value);
}

// Menu móvel e progresso de leitura
const menuToggle = $('#menuToggle');
menuToggle.addEventListener('click', () => {
  const open = $('#mainNav').classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
});
$$('#mainNav a').forEach(link => link.addEventListener('click', () => {
  $('#mainNav').classList.remove('open'); menuToggle.setAttribute('aria-expanded','false');
}));
function updateProgress() {
  const scrollable = document.documentElement.scrollHeight - window.innerHeight;
  $('#readingProgress').style.width = `${scrollable > 0 ? (window.scrollY / scrollable) * 100 : 0}%`;
}
window.addEventListener('scroll', updateProgress, {passive:true}); updateProgress();

// Abas dos simuladores: mantém os painéis inativos fora da árvore visual.
$$('.sim-tab').forEach(tab => tab.addEventListener('click', () => {
  $$('.sim-tab').forEach(item => { const active = item === tab; item.classList.toggle('active',active); item.setAttribute('aria-selected',String(active)); });
  $$('.sim-panel').forEach(panel => { const active = panel.id === `sim-${tab.dataset.tab}`; panel.hidden = !active; panel.classList.toggle('active',active); });
  if (tab.dataset.tab === 'blackbody') drawBlackbody();
  if (tab.dataset.tab === 'pool') drawPool();
}));

// Gráfico canvas acessível com descrição textual. Planck: radiância espectral por comprimento de onda.
function setupCanvas(canvas) {
  const rect = canvas.getBoundingClientRect();
  const width = Math.max(300, Math.round(rect.width || 600));
  const height = Math.max(220, Math.round(width * (canvas.height / canvas.width)));
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = width * dpr; canvas.height = height * dpr;
  const ctx = canvas.getContext('2d'); ctx.scale(dpr,dpr);
  return {ctx,width,height};
}
function drawAxes(ctx,w,h,xLabel,yLabel) {
  const left=58,right=18,top=18,bottom=45;
  ctx.strokeStyle='#b9cbd5';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,top);ctx.lineTo(left,h-bottom);ctx.lineTo(w-right,h-bottom);ctx.stroke();
  ctx.fillStyle='#61798a';ctx.font='11px Arial';ctx.textAlign='center';ctx.fillText(xLabel,(left+w-right)/2,h-10);
  ctx.save();ctx.translate(15,(top+h-bottom)/2);ctx.rotate(-Math.PI/2);ctx.fillText(yLabel,0,0);ctx.restore();
  return {left,right,top,bottom,plotW:w-left-right,plotH:h-top-bottom};
}
function planck(lambda,T) {
  const exponent = constants.h*constants.c/(lambda*constants.k*T);
  if (exponent > 700) return 0;
  return (2*constants.h*constants.c**2)/(lambda**5)/(Math.exp(exponent)-1);
}
function drawBlackbody() {
  const canvas=$('#bbChart'); if(!canvas || $('#sim-blackbody').hidden) return;
  const T=Number($('#bbTemp').value), {ctx,width:w,height:h}=setupCanvas(canvas);
  ctx.clearRect(0,0,w,h); const a=drawAxes(ctx,w,h,'Comprimento de onda (μm)','Intensidade espectral relativa');
  const min=.1,max=12, samples=240, values=[];
  let peak=0;
  for(let i=0;i<=samples;i++){const lam=min+(max-min)*i/samples;const val=planck(lam*1e-6,T);values.push({lam,val});peak=Math.max(peak,val);}
  ctx.strokeStyle='#d9e5eb';ctx.lineWidth=1;
  for(let i=0;i<=4;i++){const y=a.top+a.plotH*i/4;ctx.beginPath();ctx.moveTo(a.left,y);ctx.lineTo(w-a.right,y);ctx.stroke();}
  ctx.beginPath();values.forEach((p,i)=>{const x=a.left+(p.lam-min)/(max-min)*a.plotW;const y=a.top+a.plotH-(p.val/peak)*a.plotH*.9;i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.lineTo(w-a.right,h-a.bottom);ctx.lineTo(a.left,h-a.bottom);ctx.closePath();ctx.fillStyle='rgba(27,178,185,.14)';ctx.fill();
  ctx.beginPath();values.forEach((p,i)=>{const x=a.left+(p.lam-min)/(max-min)*a.plotW;const y=a.top+a.plotH-(p.val/peak)*a.plotH*.9;i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.strokeStyle='#0796a2';ctx.lineWidth=3;ctx.stroke();
  ctx.fillStyle='#61798a';ctx.font='10px Arial';ctx.textAlign='center';[0,2,4,6,8,10,12].forEach(v=>ctx.fillText(v,a.left+v/max*a.plotW,h-a.bottom+17));
  const peakM=constants.b/T, power=constants.sigma*T**4;
  const peakUm=peakM*1e6;
  $('#bbTempOut').textContent=`${format(T,0)} K`;$('#bbTempReadout').textContent=`${format(T,0)} K`;
  $('#bbPeak').textContent=`${format(peakUm,3)} μm`;
  $('#bbPower').textContent=`${format(power,0)} W/m²`;
  $('#bbRegion').textContent=peakUm<.4?'Ultravioleta':peakUm<.7?'Visível':'Infravermelho';
  $('#bbChartDesc').textContent=`Para ${format(T,0)} K, o pico calculado pela lei de Wien é ${format(peakUm,3)} micrômetros. A potência emissiva ideal é ${format(power,0)} watts por metro quadrado.`;
}
$('#bbTemp').addEventListener('input',drawBlackbody);

// Modelo térmico simplificado da piscina: dois períodos de 12h, energia em kWh.
// Capacidade térmica da água: 4,186 kJ/(kg K). Perdas agregadas representam evaporação+convecção+radiação+condução.
function simulatePool() {
  const initial=+$('#poolInitial').value, ambient=+$('#poolAmbient').value, irradiance=+$('#poolSun').value;
  const area=+$('#poolArea').value, depth=+$('#poolDepth').value, cover=$('#poolCover').checked, solar=$('#poolSolar').checked;
  const volume=area*depth, mass=volume*1000, waterCapacity=mass*4186/3600000; // kWh/K
  const points=[{hour:0,temp:initial}], dt=1, lossDay=0.055, lossNight=cover?0.012:0.09; // kW/m²/K, coeficientes ilustrativos agregados
  let temp=initial, incident=0;
  for(let hour=1;hour<=24;hour++){
    const daytime=hour<=12;
    const air=ambient+(daytime?2:0);
    const solarInput=daytime?irradiance*area/1000:0; // kW incident
    incident+=solarInput*dt;
    const absorbed=solarInput*0.72; // absorptância média assumida
    const collectorGain=daytime && solar ? (irradiance*area/1000)*0.35 : 0; // 35% útil simplificado
    const lossCoeff=daytime?lossDay:lossNight;
    const losses=lossCoeff*area*(temp-air); // kW; pode ser negativo se ambiente mais quente
    const net=absorbed*0.18 + collectorGain - losses; // absorção direta simplificada + coletor
    temp += net*dt/waterCapacity;
    temp=Math.max(-2,Math.min(60,temp));
    points.push({hour,temp});
  }
  return {points,volume,incident,initial,final:temp};
}
function drawLineChart(canvas,points,description) {
  const {ctx,width:w,height:h}=setupCanvas(canvas);ctx.clearRect(0,0,w,h);
  const a=drawAxes(ctx,w,h,'Tempo (horas)','Temperatura (°C)');
  const vals=points.map(p=>p.temp), min=Math.floor(Math.min(...vals)-1),max=Math.ceil(Math.max(...vals)+1);
  ctx.strokeStyle='#d9e5eb';ctx.lineWidth=1;
  for(let i=0;i<=4;i++){const y=a.top+a.plotH*i/4;ctx.beginPath();ctx.moveTo(a.left,y);ctx.lineTo(w-a.right,y);ctx.stroke();ctx.fillStyle='#61798a';ctx.font='10px Arial';ctx.textAlign='right';ctx.fillText(format(max-(max-min)*i/4,1),a.left-7,y+3);}
  ctx.beginPath();points.forEach((p,i)=>{const x=a.left+p.hour/24*a.plotW;const y=a.top+(max-p.temp)/(max-min)*a.plotH;i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.strokeStyle='#078d9a';ctx.lineWidth=3;ctx.stroke();
  ctx.lineTo(a.left+a.plotW,a.top+a.plotH);ctx.lineTo(a.left,a.top+a.plotH);ctx.closePath();ctx.fillStyle='rgba(27,178,185,.12)';ctx.fill();
  ctx.fillStyle='#61798a';ctx.font='10px Arial';ctx.textAlign='center';[0,6,12,18,24].forEach(v=>ctx.fillText(v,a.left+v/24*a.plotW,h-a.bottom+17));
  canvas.setAttribute('aria-label',description);
}
function drawPool() {
  if($('#sim-pool').hidden) return;
  const result=simulatePool();drawLineChart($('#poolChart'),result.points,`Temperatura estimada: começa em ${format(result.initial,1)} graus Celsius e termina em ${format(result.final,1)} graus Celsius após 24 horas.`);
  $('#poolInitialOut').textContent=`${format(+$('#poolInitial').value,0)} °C`;
  $('#poolAmbientOut').textContent=`${format(+$('#poolAmbient').value,0)} °C`;
  $('#poolSunOut').textContent=`${format(+$('#poolSun').value,0)} W/m²`;
  $('#poolAreaOut').textContent=`${format(+$('#poolArea').value,0)} m²`;
  $('#poolDepthOut').textContent=`${format(+$('#poolDepth').value,1)} m`;
  $('#poolFinal').textContent=`${format(result.final,1)} °C`;
  $('#poolDelta').textContent=`${result.final-result.initial>=0?'+':''}${format(result.final-result.initial,1)} °C`;
  $('#poolIncident').textContent=`${format(result.incident,1)} kWh`;
  $('#poolVolume').textContent=`${format(result.volume,1)} m³`;
  $('#poolChartDesc').textContent=`O modelo estima temperatura de ${format(result.initial,1)} graus no início para ${format(result.final,1)} graus após 24 horas.`;
}
$$('#poolInitial,#poolAmbient,#poolSun,#poolArea,#poolDepth,#poolCover,#poolSolar').forEach(el=>el.addEventListener('input',drawPool));

// Fotoelétrico: E(eV)=hc/(lambda e), f=c/lambda; corte f0=phi/h.
function updatePhoto() {
  const nm=+$('#photoWavelength').value,intensity=+$('#photoIntensity').value,phi=+$('#photoWork').value;
  const lambda=nm*1e-9, frequency=constants.c/lambda, energy=constants.h*frequency/constants.eV, kinetic=energy-phi, cutoff=constants.h/(phi*constants.eV);
  $('#photoWaveOut').textContent=`${nm} nm`;$('#photoIntensityOut').textContent=`${intensity}%`;$('#photoWorkOut').textContent=`${format(phi,1)} eV`;
  $('#photoEnergy').textContent=`${format(energy,3)} eV`;$('#photoCutoff').textContent=`${format(cutoff/1e15,3)} × 10¹⁵ Hz`;
  $('#photoKinetic').textContent=kinetic>0?`${format(kinetic,3)} eV`:'0 eV';
  if(kinetic>0){$('#photoStatus').textContent='Há emissão de elétrons';$('#photoExplanation').textContent=`A energia do fóton supera a função trabalho em ${format(kinetic,3)} eV. A intensidade altera a taxa de fótons, não a energia individual.`;}
  else{$('#photoStatus').textContent='Não há emissão';$('#photoExplanation').textContent=`A energia do fóton é inferior à função trabalho. Aumentar apenas a intensidade não provoca emissão no modelo fotoelétrico ideal.`;}
}
$$('#photoWavelength,#photoIntensity,#photoWork').forEach(el=>el.addEventListener('input',updatePhoto));

// Controle simulado: thresholds didáticos, não recomendação de engenharia.
function updateSmart() {
  const water=+$('#sensorWater').value,air=+$('#sensorAir').value,light=+$('#sensorLight').value,target=+$('#sensorTarget').value;
  const need=water<target, solarAvailable=light>=300, night=light<100;
  const heat=need&&solarAvailable, pump=heat, cover=night;
  $('#sensorWaterOut').textContent=`${water} °C`;$('#sensorAirOut').textContent=`${air} °C`;$('#sensorLightOut').textContent=`${light} lx`;$('#sensorTargetOut').textContent=`${target} °C`;
  $('#nodeWater').textContent=`${water} °C`;$('#nodeAir').textContent=`${air} °C`;$('#nodeLight').textContent=`${light} lx`;
  $('#smartStatus').textContent=water>=target?'Meta atingida':heat?'Aquecendo':'Aguardando';
  $('#nodeDecision').textContent=water>=target?'Meta térmica atingida':heat?'Radiação suficiente':'Sem ganho solar disponível';
  $('#actuatorHeat').textContent=heat?'Ativo':'Em espera';
  $('#actuatorPump').textContent=pump?'Ligada':'Desligada';
  $('#actuatorCover').textContent=cover?'Recomendada':night?'Avaliar':'Não indicada agora';
}
$$('#sensorWater,#sensorAir,#sensorLight,#sensorTarget').forEach(el=>el.addEventListener('input',updateSmart));

// Acessibilidade: controles de apresentação funcionais.
let fontScale=1;
function setFontScale(){document.documentElement.style.setProperty('--body-scale',fontScale);$('#accessStatus').textContent=`Tamanho de texto: ${Math.round(fontScale*100)}%.`;}
$('#fontUp').addEventListener('click',()=>{fontScale=Math.min(1.3,+(fontScale+.05).toFixed(2));setFontScale();});
$('#fontDown').addEventListener('click',()=>{fontScale=Math.max(.85,+(fontScale-.05).toFixed(2));setFontScale();});
$('#contrastToggle').addEventListener('click',e=>{const on=document.body.classList.toggle('high-contrast');e.currentTarget.setAttribute('aria-pressed',String(on));$('#accessStatus').textContent=on?'Modo de alto contraste ativado.':'Modo de alto contraste desativado.';});
$('#dyslexiaToggle').addEventListener('click',e=>{const on=document.body.classList.toggle('dyslexia-font');e.currentTarget.setAttribute('aria-pressed',String(on));$('#accessStatus').textContent=on?'Fonte alternativa ativada.':'Fonte padrão restaurada.';});
$('#motionToggle').addEventListener('click',e=>{const on=document.body.classList.toggle('reduce-motion');e.currentTarget.setAttribute('aria-pressed',String(on));$('#accessStatus').textContent=on?'Animações reduzidas.':'Animações restauradas.';});
$('#copyLogic').addEventListener('click',async()=>{const text=$('#logicCode').textContent;try{await navigator.clipboard.writeText(text);$('#copyLogic').textContent='Copiado!';}catch{const range=document.createRange();range.selectNodeContents($('#logicCode'));const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);$('#copyLogic').textContent='Selecione e copie';}setTimeout(()=>$('#copyLogic').textContent='Copiar lógica',2200);});

// Redesenha gráficos ao redimensionar; pequeno debounce sem dependências.
let resizeTimer;
window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{drawBlackbody();drawPool();},120);});

drawBlackbody();drawPool();updatePhoto();updateSmart();
